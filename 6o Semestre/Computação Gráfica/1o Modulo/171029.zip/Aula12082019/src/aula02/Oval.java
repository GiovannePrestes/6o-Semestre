/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aula02;

import java.awt.Color;
import java.awt.Graphics;

/**
 *
 * @author Giovanne Prestes
 */
public class Oval {
    private int x;
    private int y;
    private int widthBall;
    private int heightBall;
    private Color c;
    private int xaux;
    private int yaux;
    private Graphics g;

    public Oval(int x, int y, int width, int height, Color c, Graphics g) {
        this.x = x;
        this.y = y;
        this.widthBall = width;
        this.heightBall = height;
        this.c = c;
        this.g = g;
        int xaux = 0, yaux = 0;
    }
    
    public void move(int widthScreen, int heightScreen){
        if(xaux<=this.getX() && yaux<=this.getY()){ //(+,+)
                xaux=x;
                yaux=y;
                x += 2;
                y += 3;
            }else if(xaux<this.getX() && yaux>this.getY()){ // (+,-)
                xaux=x;
                yaux=y;
                x += 2;
                y -= 3;
            }else if(xaux>this.getX() && yaux>this.getY()){ // (-,-)
                xaux=x;
                yaux=y;
                x -= 2;
                y -= 3;
            }else{ //(-,+)
                xaux=x;
                yaux=y;
                x -= 2;
                y += 3;
            }
            
            if(y > (heightScreen-heightBall)){
                yaux = y;
                y -= 3;
            }else if(x > (widthScreen-widthBall)){
                xaux=x;
                x -= 2;
            }else if(y < 20){
                yaux=y;
                y += 3;
            }else if(x < 0){
                xaux = x;
                x += 2;
            }
    }
    
    public void pintarBola(){
        g.setColor(c);
        g.fillOval(x, y, widthBall, heightBall);
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getWidthBall() {
        return widthBall;
    }

    public void setWidthBall(int widthBall) {
        this.widthBall = widthBall;
    }

    public int getHeightBall() {
        return heightBall;
    }

    public void setHeightBall(int heightBall) {
        this.heightBall = heightBall;
    }

    public Color getC() {
        return c;
    }

    public void setC(Color c) {
        this.c = c;
    }
    
    
}
